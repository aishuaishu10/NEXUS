const employeesData = [
  {
    id: 1,
    firstName: 'Harsha',
    lastName: 'KR',
    email: 'harsha@gmail.com.com',
    salary: '95000',
    date: '2024-04-11'
  },
  {
    id: 2,
    firstName: 'Akshay',
    lastName: 'M',
    email: 'akshaym@gmail.com',
    salary: '80000',
    date: '2019-04-17'
  },
  {
    id: 3,
    firstName: 'Darshan',
    lastName: 'H',
    email: 'darshan@gmail.com',
    salary: '79000',
    date: '2019-05-01'
  },
  {
    id: 4,
    firstName: 'Suchitha',
    lastName: 'G',
    email: 'suchitha@gmail.com',
    salary: '56000',
    date: '2019-05-03'
  },
  {
    id: 5,
    firstName: 'Nagalakshmi',
    lastName: 'J',
    email: 'nagalakshmi@gmail.com',
    salary: '65000',
    date: '2019-06-13'
  },
];

export { employeesData };
